# batcat

> This command is an alias of `bat`.
> More information: <https://github.com/sharkdp/bat>.

- View documentation for the original command:

`tldr bat`
