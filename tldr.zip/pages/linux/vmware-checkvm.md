# vmware-checkvm

> Checks to see if the current host is a VMware VM or not.

- Return the current VMware software version (exit status determines whether the system is a VM or not):

`vmware-checkvm`

- Return the VMware hardware version:

`vmware-checkvm -h`
