# lscpu

> Displays information about the CPU architecture.
> More information: <https://manned.org/lscpu>.

- Display information about all CPUs:

`lscpu`

- Display information in a table:

`lscpu --extended`

- Display only information about offline CPUs in a table:

`lscpu --extended --offline`
